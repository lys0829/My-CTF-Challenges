
<!DOCTYPE html>
<html lang="zh-Hans-TW" prefix="og: http://ogp.me/ns#">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta property="og:title" content="AIS3 2021 新型態資安暑期課程">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="AIS3 2021 新型態資安暑期課程">
    <meta property="og:url" content="https://ais3.org">
    <meta property="og:image" content="/img/AIS3_LOGO-02.png">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="/css/base.css">
    <link rel="icon" type="image/png" href="/img/AIS3_favicon.png" />
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="/js/base.js"></script>
    <title>AIS3 2021</title>
    
    <style>

        #index {
            background-image: url(/img/ais3_2021_background.png);
        }

        #index-img {
            width: 50%;
            height: 50%;
            margin-top: 5% !important;
            margin: 1%;
        }
        #index-button-img {
            width: 2%;
            height: 5%;
            margin: 3%;
        }

        /*.image img {
            height: 110px !important;
        }*/

        .purpose p {
            margin-top: 10px;
            line-height: 35px;
        }
    </style>

</head>
<body data-spy="scroll" data-target="#navbar" data-offset="5" style="position: relative;">
    <div class="container">

        <div class="modal fade" id="showListModal" tabindex="-1" role="dialog" aria-labelledby="showListModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5 style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;&#x9810;&#x8A08;&#x4E0B;&#x5348; 3 &#x9EDE;&#x91CD;&#x65B0;&#x958B;&#x653E;</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary mx-auto" data-dismiss="modal">關閉</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="registerModal" tabindex="-1" role="dialog" aria-labelledby="registerModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5 style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;報名已截止</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary mx-auto" data-dismiss="modal">關閉</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="registerNotStartModal" tabindex="-1" role="dialog" aria-labelledby="registerNotStartModal" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5 style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;報名尚未開始</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary mx-auto" data-dismiss="modal">關閉</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="listModal" tabindex="-1" role="dialog" aria-labelledby="listModal" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5 style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;名單尚未公布</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary mx-auto" data-dismiss="modal">關閉</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="prexamModal" tabindex="-1" role="dialog" aria-labelledby="prexamModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5 style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;尚未開放測驗</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary mx-auto" data-dismiss="modal">關閉</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="courseModal" tabindex="-1" role="dialog" aria-labelledby="courseModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5 style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;尚未公布課程</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary mx-auto" data-dismiss="modal">關閉</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="registerSuccessModal" tabindex="-1" role="dialog" aria-labelledby="registerSuccessLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body alert alert-success">
                        <h5 class="text-success" style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;報名成功</h5>
                        <div style="text-align: center">
                            <button type="button" class="btn btn-success" data-dismiss="modal">關閉</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="mailSendModal" tabindex="-1" role="dialog" aria-labelledby="mailSendLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body alert alert-success">
                        <h5 class="text-success" style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;已將重設密碼連結寄出。</h5>
                        <div style="text-align: center">
                            <button type="button" class="btn btn-success" data-dismiss="modal">關閉</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="resetSuccessModal" tabindex="-1" role="dialog" aria-labelledby="resetSuccessLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body alert alert-success">
                        <h5 class="text-success" style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;重設成功。</h5>
                        <div style="text-align: center">
                            <button type="button" class="btn btn-success" data-dismiss="modal">關閉</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="uploadSuccessModal" tabindex="-1" role="dialog" aria-labelledby="uploadSuccessLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body alert alert-success">
                        <h5 class="text-success" style="text-align: center"><i class="fas fa-exclamation-circle"></i>&nbsp;上傳成功。</h5>
                        <div style="text-align: center">
                            <button type="button" class="btn btn-success" data-dismiss="modal">關閉</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <nav id="navbar" class="navbar navbar-expand-lg fixed-top navbar-dark">
            <a class="navbar-brand" href="/"><img src="/img/AIS3logo.png" alt="AIS3"><span class="test d-none d-sm-inline">&nbsp;新型態資安實務主題課程</span></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a id="register" class="nav-link" href="/Account/Register">報名</a>
                    </li>
                    <li class="nav-item">
                        <a id="register" class="nav-link" href="/Home/Recommendation">甄選</a>
                    </li>
                    <li class="nav-item">
                        <a id="speaker" class="nav-link" href="/Home/Speaker">講師</a>
                    </li>
                    <li class="nav-item">
                        <a id="course" class="nav-link" href="/Home/Course">課程</a>
                    </li>
                    <li class="nav-item">
                        <a id="news" class="nav-link" href="/Home/News">新聞</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">回顧</a>
                        <div class="dropdown-menu dropdown-menu-right shadow back" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="/2015/index.html">2015</a>
                            <a class="dropdown-item" href="/2016/index.html">2016</a>
                            <a class="dropdown-item" href="/2017/index.html">2017</a>
                            <a class="dropdown-item" href="/2018/index.html">2018</a>
                            <a class="dropdown-item" href="/2019/index.html">2019</a>
                            <a class="dropdown-item" href="/2020">2020</a>
                        </div>
                    </li>
                        <li class="nav-item" data-toggle="modal" data-target="#loginModal">
                            <a class="nav-link" href="/Account/Login">登入</a>
                        </li>
                </ul>
            </div>
        </nav>

    </div>
    <div class="content">
        

<script language="javascript" src="/js/index.js"></script>
<link rel="stylesheet" type="text/css" href="/css/index.css">



<div>
    <div id="index" class="home full-view">
        <img id="index-img" src="/img/ais3_2021_index.png" />
        <br />
        <img id="index-button-img" src="/img/ais3_2021_index_button.png" />
        <br />
        <div id="index-date">
            <div class="row justify-content-center">
                <div class="col-xl-3 col-lg-4">
                    <div class="wrapper">
                        <a id="register" class="button" href="#">
                            <div class="row no-gutters justify-content-center">
                                <div class="image">
                                    <img src="/img/ais3_2021_reg_time_renew.png" alt="報名">
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4">
                    <div class="wrapper">
                        <a id="register" class="button" href="#">
                            <div class="row no-gutters justify-content-center">
                                <div class="image">
                                    <img src="/img/ais3_2021_pre_exam_quiz.png" alt="Pre-Exam 測驗">
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4">
                    <div class="wrapper">
                        <a id="register" class="button" href="#">
                            <div class="row no-gutters justify-content-center">
                                <div class="image">
                                    <img src="/img/ais3_2021_sel_info_submit.png" alt="甄選資料繳交">
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4">
                    <div class="wrapper">
                        <a id="register" class="button" href="#">
                            <div class="row no-gutters justify-content-center">
                                <div class="image">
                                    <img src="/img/ais3_2021_summer_course.png" alt="暑期課程">
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="intro-purpose container">
            <div class="purpose">
                <span style="color: #ffcc66;font-size: 32px; font-weight: bold; margin-bottom: 15px;">目的</span>
                <p>
                    <strong>
                        邀請具資安實務與國際資安競賽實戰經驗之國內外專家學者進行授課， 透過資訊安全實務(或實戰)之經驗分享與演練， 提升本課程學員之資安實務的能力與深度。
                    </strong>
                </p>
            </div>
        </div>
    </div>

    <div id="intro" class="intro full-view">
        <div class="row vdivide">
            <div class="col-xl-4 col-lg-4">
                <div class="about-content">
                    <h3><span class="symbol">#</span>課程目的</h3>
                    <p>
                        邀請具資安實務與國際資安競賽實戰經驗之國內外專家學者進行授課，透過資訊安全實務(或實戰)之經驗分享與演練，提升本課程學員之資安實務的能力與深度。
<p>
                </div>
                <div class="about-content">

                    <h3><span class="symbol">#</span>課程主題</h3>
                    <ol>
                        <li>以落實產業資安實務為導向設計課程內容，並引導學員依興趣組成跨校跨級學習小組，製作與展示專題成果。</li>
                        <li>課程內容包含：網頁安全、軟體安全、關鍵基礎設施安全、企業網路安全、資料安全(數位鑑識、國家安全)等資安實務課程。課程規劃與課程授課講師將另行公告於本活動網頁，<a href="https://ais3.org/">https://ais3.org/</a>。</li>
                    </ol>
                </div>

                <div class="about-content">
                    <h3><span class="symbol">#</span>課程時間與地點</h3>
                    <ol>
                        <li><span class="font-weight-bold">110年 7 月 26 日至 8 月 1 日，共計7日於輔仁大學進行</span>其中 7 月 27 日至 7 月 31 日進行資安實務課程授課，課程以每日上午 9 時 30 分至下午 5 時為原則，實際時間依當日課程安排進行微調，共計30小時。</li>
                        <li>上課地點：輔仁大學國璽樓2樓國際會議廳。</li>
                        <li>因應新型冠狀病毒(COVID-19)疫情，主辦單位將視疫情狀況有權調整課程內容與進行方式或取消課程，若有相關異動將公布於本網頁，恕不另行通知。</li>
                    </ol>
                </div>

                <div class="about-content">
                    <h3><span class="symbol">#</span>報名資格</h3>
                    <ol>
                        <li>具備資訊安全基礎能力以及<span class="font-weight-bold">未曾參加過或曾參加過AIS3新型態資安暑期課程兩次以內之本國籍在校學生。</span></li>
                        <li>主辦單位將視報名狀況，保留部分學員名額調整權利。</li>
                    </ol>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4">
                <div class="about-content">
                    <h3><span class="symbol">#</span>報名時間及方式</h3>
                    <ol>
                        <li>報名錄取考核方式為「Pre-exam資安實務測驗」及「甄選」兩種方式，並各錄取 75 人，共 150 人；另各備取 15 人，共 30 人。學員可於報名時自行選擇錄取考核方式(可複選)</li>
                        <li>報名時間：<span class="font-weight-bold">自 110 年 4 月 26 日上午 10 時至 110 年 5 月 6 日下午 6 時止</span>，主辦單位得視報名實際情形延後報名截止時間或新增第二階段報名，報名時請備註是否於校內住宿。</li>
                        <li>一律採網路報名，送出報名資訊後並收到e-mail報名成功通知信件，始完成報名。報名網址：<a href="https://ais3.org/">https://ais3.org/</a></li>
                        <li>
                            Pre-exam資安實務測驗: <br />
                            <span class="li-indent"></span>1. 收到e-mail報名成功通知信件後，請登入本活動網站(<a href="https://ais3.org/">https://ais3.org/</a>)，依活動指示於<span class="font-weight-bold">110年 5 月 22 日上午 10 時 30 分至 110 年 5 月 24 日下午 5 時間參加本課程 pre-exam 資安實務測驗，此測驗結果將作為學員錄取資格審核依據，請務必於規範時間內完成測驗。</span>
                            <br />
                            <span class="li-indent"></span>2. 錄取通知：將於 110 年 5 月 31 日前以 e-mail 方式個別通知報名評選結果，並於本課程網頁公告錄取名單。
                        </li>
                        <li>
                            甄選: <br />
                            <span class="li-indent"></span>1. 收到e-mail報名成功通知信件後，<span class="font-weight-bold">請於 110 年 5 月 31 日上午 10 時至 110 年 6 月 6 日下午 6 時前</span>，繳交<span class="font-weight-bold">甄選資料</span>，逾期將不予受理。
                            <br />
                            <span class="li-indent"></span>2. <span class="font-weight-bold">甄選資料一律採網路形式繳交</span>，請將填具好的資料上傳至 <a href="https://ais3.org/">https://ais3.org/</a>。
                            <br />
                            <span class="li-indent"></span>3. 甄選資料繳交後將由主辦單位邀請企業講師及資安領域專家學者，以匿名方式評估申請者相關能力及表現。
                            <br />
                            <span class="li-indent"></span>4. 錄取通知：將於110年7月13日前以e-mail方式個別通知報名評選結果，並於本課程網頁公告錄取名單。
                        </li>
                    </ol>
                </div>

                <div class="about-content">
                    <h3><span class="symbol">#</span>活動時程</h3>
                    <ol>
                        <li>報名時間：110 年 4 月 26 日上午 10 時至 110 年 5 月 6 日下午 6 時止。</li>
                        <li>Pre-exam 資安實務測驗日期：110 年 5 月 22 日上午 10 時 30 分至 110 年 5 月 24 日下午 5 時前。</li>
                        <li>Pre-exam錄取通知：110 年 5 月 31 日前通知與公告。</li>
                        <li>甄選資料繳交時間：自 110 年 5 月 31 日上午 10 時至 110 年 6 月 6 日下午 6 時止。</li>
                        <li>甄選錄取通知：110 年 7 月 13 日前通知與公告。</li>
                        <li>課程時間：110 年 7 月 26 日至 8 月 1 日，共計 7 日</li>
                    </ol>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4">
                <div class="about-content">
                    <h3><span class="symbol">#</span>注意事項</h3>
                    <ol>
                        <li><span class="font-weight-bold">參加學員須自理所需交通及生活費用，無需另繳課程費用。</span></li>
                        <li>本次課程補助學生 110 年 7 月 25 日至 7 月 31 日，共 7 天，於輔仁大學校內學生宿舍住宿全額費用，參與校內住宿學生請自行攜帶睡袋及盥洗用具。</li>
                        <li>課程出席率超過授課總時數之百分之九十以上(參與27小時以上的課程，若無法出席需事先繳交請假單)並全程參與產業資安實務專題展示者，由「教育部資訊安全人才培育計畫推動辦公室」頒發研習結業證書。</li>
                        <li>參加本課程成績優異之學員，經由授課導師推薦，將有機會獲得教育部補助出國參加國際資安競賽或國際資安研習課程等。</li>
                        <li>本系列課程以<span class="font-weight-bold">落實產業資安實務</span>為教學核心，部份課程由講師視需要安排作業，期間按學員報名時依興趣所選擇之主題組成專題小組，請各小組發表專題報告，表現優異隊伍將頒發獎狀予以鼓勵。</li>
                        <li><span class="font-weight-bold">請攜帶筆記型電腦</span>，以便進行課堂實作演練。</li>
                        <li>請於課程開始10分鐘前由本人至報到處完成簽到，上、下課時間以講師授課為準，嚴禁由他人冒名頂替上課。遲到或早退一小時以上者，該堂課以曠課論。</li>
                        <li>如因事、病不克上課者，請以書面請假，未書面請假者，一律以曠課登錄。</li>
                        <li>為維護良好的學習環境，請勿在教室內部飲食。</li>
                        <li>其他課程訊息未盡事宜，詳請參考本課程網頁。</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="support">
        <div class="container">
            <p>技術與講師協助</p>
            <div class="row justify-content-center">
                <div class="block">
                    <img src="/img/sponsor/ntust.png">
                </div>
                <!--<div class="block">
                    <img src="/img/sponsor/ntct.jpeg">
                </div>
                <div class="block">
                    <img src="/img/sponsor/ntu.jpg">
                </div>
                <div class="block">
                    <img src="/img/sponsor/ntust.png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/fj.jpg">
                </div>
                <div class="block">
                    <img src="/img/sponsor/16.png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (1).jpg">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (2).jpg">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (3).jpg">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (4).jpg">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (5).png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (6).png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (7).png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (8).png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (9).png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (10).png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (11).png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (12).png">
                </div>
                    -->
            </div>
            <!--
            <p>贊助</p>
            <div class="row justify-content-center">
                <div class="block">
                    <img src="/img/sponsor/2020/image (5).png">
                </div>
                <div class="block">
                    <img src="/img/sponsor/2020/image (13).png">
                </div>
            </div>
            -->
        </div>
    </div>
</div>
    </div>

    <footer>
        <div class="footer">
            <div class="info">
                <div class="row">
                    <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4">指導單位：</div>
                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">教育部資訊及科技教育司</div>

                    <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4">主辦單位：</div>
                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">教育部資訊安全人才培育計畫推動辦公室</div>

                    <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4">協辦單位：</div>
                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">國立臺灣科技大學資訊工程系、國立臺灣科技大學資訊管理系</div>

                    <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4"></div>
                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">國立陽明交通大學資訊工程學系、國立臺灣大學資訊工程學系</div>

                    <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4"></div>
                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">逢甲大學資訊工程學系、輔仁大學資訊工程學系、元智大學資訊工程學系</div>

                    <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4">聯絡窗口：</div>
                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">陳雯芳&nbsp;小姐&nbsp;</div>

                    <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4"></div>
                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">活動及報名網站 <a style="color: black;" href="https://ais3.org/">https://ais3.org/</a></div>
                    <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4"></div>
                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">連絡電話：(02)2733-3141&nbsp;分機&nbsp;7677<br></div>
                    <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4"></div>
                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">e-mail：service@ais3.org</div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">© 2021 Advanced Information Security - Summer School </div>
            </div>
        </div>
    </footer>
    

</body>
</html>